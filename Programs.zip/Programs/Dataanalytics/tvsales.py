import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model 
from sklearn.crossvalidation import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.matrics import r2_score
df=pd.read_csv('advertising.csv')
print(df.head(10))
print(df.describe())
print(df.shape())
new_df=df [['TV','Sales']]
print(new_df)
new_df['TV'].dropna()
new_df['Sales'].dropna()
new_df.dropna(inplace=True)
x=np.array(new_df[['TV']])
y=np.array(new_df[['Sales']])
print(x.shape)
print(y.shape)
plt.scatter (x,y,color="red")
plt.xlabel('Sales')
plt.title('TV vs Sales')
plt.show()
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.30,random_state=15)
regressor=LinearRegression()
regressor.fit(x_train,y_train)
plt.scatter(x_test,y_test,color="green")
plt.plot(x_train,regressor.predict(x_train),color="red",linewidth=3)
plt.title("Regression(Test Set)")
plt.xlabel('TV')
plt.ylabel('Sales')
plt.show()
plt.scatter(x_train,y_train,color="blue")
plt.plot(x_train,regressor.predict(x_train),color="red",linewidth=3)
plt.title("Regression(Test Set)")
plt.xlabel('TV')
plt.ylabel('Sales')
plt.show()
